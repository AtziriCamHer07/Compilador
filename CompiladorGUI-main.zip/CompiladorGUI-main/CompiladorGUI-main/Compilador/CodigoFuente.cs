﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador
{
    public class CodigoFuente
    {
        private readonly List<string> _lineas;

        private CodigoFuente(List<string> lineas)
        {
            _lineas = lineas;
        }

        public static CodigoFuente DesdeTexto(string texto)
        {
            if (texto == null)
            {
                texto = string.Empty;
            }

            texto = texto.Replace("\r\n", "\n").Replace("\r", "\n");
            var arreglo = texto.Split('\n');
            return new CodigoFuente(arreglo.ToList());
        }

        public int NumeroLineas => _lineas.Count;

        //indice 1-base: 1, 2, 3, ...
        public string ObtenerLineas(int numerolinea)
        {
            if (numerolinea < 1 || numerolinea > _lineas.Count)
            {
                throw new ArgumentOutOfRangeException(nameof(numerolinea));
            }
            return _lineas[numerolinea - 1];
        }

        public IEnumerable<string> ObtenerTodasLasLineas() => _lineas;
    }
}
