﻿namespace Compilador.UI.Forms
{
    partial class FrmCompilador
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            toolStrip1 = new ToolStrip();
            btnNuevo = new ToolStripButton();
            btnAbrir = new ToolStripButton();
            btnGuardar = new ToolStripButton();
            btnCompilar = new ToolStripButton();
            btnTema = new ToolStripButton();
            btnSalir = new ToolStripButton();
            splitMain = new SplitContainer();
            splitEditor = new SplitContainer();
            splitBottom = new SplitContainer();
            panel2 = new Panel();
            txtEstatus = new TextBox();
            panel1 = new Panel();
            label1 = new Label();
            gridSimbolos = new DataGridView();
            openFileDialog1 = new OpenFileDialog();
            saveFileDialog1 = new SaveFileDialog();
            panel3 = new Panel();
            panel4 = new Panel();
            txtTokens = new TextBox();
            toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitMain).BeginInit();
            splitMain.Panel1.SuspendLayout();
            splitMain.Panel2.SuspendLayout();
            splitMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitEditor).BeginInit();
            splitEditor.Panel2.SuspendLayout();
            splitEditor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitBottom).BeginInit();
            splitBottom.Panel1.SuspendLayout();
            splitBottom.Panel2.SuspendLayout();
            splitBottom.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)gridSimbolos).BeginInit();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // toolStrip1
            // 
            toolStrip1.GripStyle = ToolStripGripStyle.Hidden;
            toolStrip1.ImageScalingSize = new Size(24, 24);
            toolStrip1.Items.AddRange(new ToolStripItem[] { btnNuevo, btnAbrir, btnGuardar, btnCompilar, btnTema, btnSalir });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(1331, 78);
            toolStrip1.TabIndex = 1;
            // 
            // btnNuevo
            // 
            btnNuevo.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNuevo.Image = Properties.Resources._new;
            btnNuevo.Margin = new Padding(5);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Padding = new Padding(5);
            btnNuevo.Size = new Size(93, 68);
            btnNuevo.Text = "Nuevo";
            btnNuevo.TextImageRelation = TextImageRelation.ImageAboveText;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnAbrir
            // 
            btnAbrir.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAbrir.Image = Properties.Resources.open;
            btnAbrir.Margin = new Padding(5);
            btnAbrir.Name = "btnAbrir";
            btnAbrir.Padding = new Padding(5);
            btnAbrir.Size = new Size(77, 68);
            btnAbrir.Text = "Abrir";
            btnAbrir.TextImageRelation = TextImageRelation.ImageAboveText;
            btnAbrir.Click += btnAbrir_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGuardar.Image = Properties.Resources.save;
            btnGuardar.Margin = new Padding(5);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Padding = new Padding(5);
            btnGuardar.Size = new Size(106, 68);
            btnGuardar.Text = "Guardar";
            btnGuardar.TextImageRelation = TextImageRelation.ImageAboveText;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnCompilar
            // 
            btnCompilar.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCompilar.Image = Properties.Resources.compilar;
            btnCompilar.Margin = new Padding(5);
            btnCompilar.Name = "btnCompilar";
            btnCompilar.Padding = new Padding(5);
            btnCompilar.Size = new Size(117, 68);
            btnCompilar.Text = "Compilar";
            btnCompilar.TextImageRelation = TextImageRelation.ImageAboveText;
            btnCompilar.Click += btnCompilar_Click;
            // 
            // btnTema
            // 
            btnTema.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTema.Image = Properties.Resources.libros__1_;
            btnTema.Margin = new Padding(5);
            btnTema.Name = "btnTema";
            btnTema.Padding = new Padding(5);
            btnTema.Size = new Size(79, 68);
            btnTema.Text = "Tema";
            btnTema.TextImageRelation = TextImageRelation.ImageAboveText;
            // 
            // btnSalir
            // 
            btnSalir.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalir.Image = Properties.Resources.exit;
            btnSalir.Margin = new Padding(5);
            btnSalir.Name = "btnSalir";
            btnSalir.Padding = new Padding(5);
            btnSalir.Size = new Size(70, 68);
            btnSalir.Text = "Salir";
            btnSalir.TextImageRelation = TextImageRelation.ImageAboveText;
            // 
            // splitMain
            // 
            splitMain.Dock = DockStyle.Fill;
            splitMain.Location = new Point(0, 78);
            splitMain.Name = "splitMain";
            splitMain.Orientation = Orientation.Horizontal;
            // 
            // splitMain.Panel1
            // 
            splitMain.Panel1.Controls.Add(splitEditor);
            // 
            // splitMain.Panel2
            // 
            splitMain.Panel2.Controls.Add(splitBottom);
            splitMain.Size = new Size(1331, 609);
            splitMain.SplitterDistance = 430;
            splitMain.TabIndex = 0;
            // 
            // splitEditor
            // 
            splitEditor.Dock = DockStyle.Fill;
            splitEditor.Location = new Point(0, 0);
            splitEditor.Name = "splitEditor";
            // 
            // splitEditor.Panel1
            // 
            splitEditor.Panel1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            // 
            // splitEditor.Panel2
            // 
            splitEditor.Panel2.Controls.Add(panel4);
            splitEditor.Panel2.Controls.Add(panel3);
            splitEditor.Size = new Size(1331, 430);
            splitEditor.SplitterDistance = 1072;
            splitEditor.TabIndex = 0;
            // 
            // splitBottom
            // 
            splitBottom.Dock = DockStyle.Fill;
            splitBottom.Location = new Point(0, 0);
            splitBottom.Name = "splitBottom";
            // 
            // splitBottom.Panel1
            // 
            splitBottom.Panel1.Controls.Add(panel2);
            splitBottom.Panel1.Controls.Add(panel1);
            // 
            // splitBottom.Panel2
            // 
            splitBottom.Panel2.Controls.Add(gridSimbolos);
            splitBottom.Size = new Size(1331, 175);
            splitBottom.SplitterDistance = 1072;
            splitBottom.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.Controls.Add(txtEstatus);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 55);
            panel2.Name = "panel2";
            panel2.Size = new Size(1072, 120);
            panel2.TabIndex = 1;
            // 
            // txtEstatus
            // 
            txtEstatus.Dock = DockStyle.Fill;
            txtEstatus.Font = new Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtEstatus.Location = new Point(0, 0);
            txtEstatus.Multiline = true;
            txtEstatus.Name = "txtEstatus";
            txtEstatus.ReadOnly = true;
            txtEstatus.ScrollBars = ScrollBars.Vertical;
            txtEstatus.Size = new Size(1072, 120);
            txtEstatus.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1072, 55);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(27, 14);
            label1.Name = "label1";
            label1.Size = new Size(307, 38);
            label1.TabIndex = 0;
            label1.Text = "Estatus del compilador";
            // 
            // gridSimbolos
            // 
            gridSimbolos.AllowUserToAddRows = false;
            gridSimbolos.AllowUserToDeleteRows = false;
            gridSimbolos.ColumnHeadersHeight = 29;
            gridSimbolos.Dock = DockStyle.Fill;
            gridSimbolos.Location = new Point(0, 0);
            gridSimbolos.Name = "gridSimbolos";
            gridSimbolos.ReadOnly = true;
            gridSimbolos.RowHeadersVisible = false;
            gridSimbolos.RowHeadersWidth = 51;
            gridSimbolos.Size = new Size(255, 175);
            gridSimbolos.TabIndex = 0;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(255, 83);
            panel3.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Controls.Add(txtTokens);
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(0, 83);
            panel4.Name = "panel4";
            panel4.Size = new Size(255, 347);
            panel4.TabIndex = 1;
            // 
            // txtTokens
            // 
            txtTokens.Dock = DockStyle.Fill;
            txtTokens.Font = new Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtTokens.Location = new Point(0, 0);
            txtTokens.Multiline = true;
            txtTokens.Name = "txtTokens";
            txtTokens.ReadOnly = true;
            txtTokens.ScrollBars = ScrollBars.Vertical;
            txtTokens.Size = new Size(255, 347);
            txtTokens.TabIndex = 1;
            txtTokens.Text = "Listado de tokens";
            // 
            // FrmCompilador
            // 
            ClientSize = new Size(1331, 687);
            Controls.Add(splitMain);
            Controls.Add(toolStrip1);
            Name = "FrmCompilador";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Compilador";
            WindowState = FormWindowState.Maximized;
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            splitMain.Panel1.ResumeLayout(false);
            splitMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitMain).EndInit();
            splitMain.ResumeLayout(false);
            splitEditor.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitEditor).EndInit();
            splitEditor.ResumeLayout(false);
            splitBottom.Panel1.ResumeLayout(false);
            splitBottom.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitBottom).EndInit();
            splitBottom.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)gridSimbolos).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ToolStrip toolStrip1;
        private ToolStripButton btnNuevo;
        private ToolStripButton btnAbrir;
        private ToolStripButton btnGuardar;
        private ToolStripButton btnCompilar;
        private ToolStripButton btnTema;
        private ToolStripButton btnSalir;

        private SplitContainer splitMain;
        private SplitContainer splitEditor;
        private SplitContainer splitBottom;
        private DataGridView gridSimbolos;
        private OpenFileDialog openFileDialog1;
        private SaveFileDialog saveFileDialog1;
        private Panel panel2;
        private TextBox txtEstatus;
        private Panel panel1;
        private Label label1;
        private Panel panel3;
        private Panel panel4;
        private TextBox txtTokens;
    }
}
