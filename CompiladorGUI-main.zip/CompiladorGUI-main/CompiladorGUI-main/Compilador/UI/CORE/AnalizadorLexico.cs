﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador.UI.CORE
{
    public class AnalizadorLexico
    {
        private readonly MatrizTransicion _matriz;
        private readonly PalabrasReservadas _palabrasReservadas;

        public AnalizadorLexico()
        {
            _matriz = new MatrizTransicion();
            _palabrasReservadas = new PalabrasReservadas();
        }

        public ResultadoLexico Analizar(CodigoFuente fuente)
        {
            var resultado = new ResultadoLexico();
            resultado.AgregarAviso("Lexico iniciado");

            try
            {
                for (int numLinea = 1; numLinea <= fuente.NumeroLineas; numLinea++)
                {
                    ProcesarLinea(fuente.ObtenerLineas(numLinea), numLinea, resultado);
                }

                resultado.AgregarAviso("Lexico finalizado correctamente");
            }
            catch (Exception ex)
            {
                resultado.AgregarAviso("Error grave en lexico: " + ex.Message);
            }

            return resultado;
        }

        private void ProcesarLinea(string lineaOriginal, int numlinea, ResultadoLexico resultado)
        {
            int estado = 0;
            var lexema = new StringBuilder();
            int token = 0;

            //agregar un espacio al final para forzar el cierre de lexemas
            string linea = (lineaOriginal ?? string.Empty) + " ";

            for (int i = 0; i < linea.Length; i++)
            {
                char c = linea[i];
                int columna = _matriz.ObtenerColumna(c);
                int valorMatriz = _matriz.SiguienteEstado(estado, columna);

                if (valorMatriz == 0)
                {
                    //reset
                    estado = 0;
                    lexema.Clear();
                    token = 0;
                }
                else if (valorMatriz < 100)
                {
                    //estado interno (leyendo ID o numero)
                    estado = valorMatriz;
                    lexema.Append(c);
                    token = 0;
                }
                else if (valorMatriz == 100)
                {
                    //fin del ID / palabra reservada
                    string lex = lexema.ToString();
                    token = _palabrasReservadas.ObtenerToken(lex);
                    resultado.Tokens.Add(new Token(token, lex, numlinea));
                    Console.WriteLine($"Token: {token} | Lexema: {lex} | Linea: {numlinea}");
                    lexema.Clear();
                    estado = 0;
                    i--; //reprocesar el mismo caracter en el estado 0
                }
                else if (valorMatriz == 200)
                {
                    //fin de numero entero
                    string lex = lexema.ToString();
                    token = 200; //codigo para numero entero
                    resultado.Tokens.Add(new Token(token, lex, numlinea));
                    Console.WriteLine($"Token: {token} | Lexema: {lex} | Linea: {numlinea}");
                    lexema.Clear();
                    estado = 0;
                    i--; //reprocesar el mismo caracter en el estado 0
                }
                else if (valorMatriz > 500)
                {
                    //error lexico
                    string mensaje = $"ERROR: En la linea [{numlinea}] hay un simbolo no reconocido: '{c}'";
                    resultado.AgregarAviso(mensaje);
                    Console.WriteLine(mensaje);
                    //reset tras el error
                    estado = 0;
                    lexema.Clear();
                    token = valorMatriz;
                }
            }
        }
    }
}
