﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador
{
    public class MatrizTransicion
    {
        //columnas:
        // 0 = letra o '_'
        // 1 = digito
        // 2 = espacio den blanco
        // 3 = otro simbolo (ej. operadores, delimitadores, etc)

        //estados o renglones:
        // 0 = inicial
        // 1 = leyendo ID / palabras reservadas
        // 2 = leyendo numero entero

        //valores aceptados
        // 100 = aceptar ID / palabra reservadas
        // 200 = aceptar numero entero
        // >500 = error lexico

        private readonly int[,] _matriz = 
        {
            //       L    D  ESP  OTRO
            /**/ {   1,   2,   0, 501 }, //inicio
            /**/ {   1,   1, 100, 100 }, // ID o palabra reservada
            /**/ { 501,   2, 200, 200 } // numero entero
        };

        public int ObtenerColumna(char c)
        {
            if (char.IsLetter(c) || c == '_')
            {
                return 0; //letra o barra baja
            }

            if (char.IsDigit(c))
            {
                return 1; //digito
            }

            if (char.IsWhiteSpace(c))
            {
                return 2; //espacio
            }

            return 3; //otro caracter
        }

        public int SiguienteEstado(int estado, int columna)
        {
            //segun la cantidad de estados
            if (estado < 0 || estado > 2)
            {
                throw new ArgumentOutOfRangeException(nameof(estado));
            }

            return _matriz[estado, columna];
        }
    }
}
