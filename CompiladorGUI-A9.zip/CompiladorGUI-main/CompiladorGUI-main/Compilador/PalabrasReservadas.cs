﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compilador
{
    public class PalabrasReservadas
    {
        private readonly Dictionary<string, int> _mapa = new Dictionary<string, int> {
            { "var", 102 },
            { "integer", 103 },
            { "float", 104 },
            { "if", 105 },
            { "then", 106 },
            { "else", 107 },
            { "while", 108 }
        };

        //102 sera el token para id, palabras reservadas, identificadores, variables
        public int ObtenerToken(string lexema)
        {
            if (string.IsNullOrEmpty(lexema))
            {
                return 101;
            }

            var clave = lexema.ToUpperInvariant();
            return _mapa.TryGetValue(clave, out int token) ? token : 101; //identificador
        }
    }
}
