# Project Analysis: Compilador

This project is a compiler application built with C# and Windows Forms. It includes a lexical analyzer and a syntactic analyzer for a custom Pascal-like language.

## Project Structure

The project is organized into three main areas:

- **Root Directory**: Contains project configuration (`.csproj`), resources, and legacy files.
- **`UI/CORE`**: The heart of the compiler logic.
  - **`AnalizadorLexico.cs`**: Implements the lexical analyzer using a Deterministic Finite Automaton (DFA) approach.
  - **`AnalizadorSintactico.cs`**: Implements the syntactic analyzer using recursive descent. It also performs basic semantic checks.
  - **`MatrizTransicion.cs`**: Defines the transition matrix for the DFA.
  - **`PalabrasReservadas.cs`**: Defines the language's keywords.
  - **`Token.cs`, `Simbolo.cs`, `ResultadoLexico.cs`**: Data structures for compiler operations.
  - **`Program.cs`**: The application's entry point.
- **`UI/FORMS`**: Contains the graphical user interface.
  - **`FrmCompilador.cs`**: The main window where users can write code, run the analysis, and view results (tokens, errors, etc.).

## Supported Language Features

The compiler supports a Pascal-style syntax with the following features:

### 1. Program Structure
- `PROGRAM name;`
- `VAR` section for variable declarations.
- `PROCEDURE` declarations.
- `BEGIN ... END.` main block.

### 2. Variable Declarations
- Multiple variables can be declared at once: `a, b, c: INT;`
- Supported types: `INT` (integer) and `FLOAT` (real).

### 3. Control Flow
- `IF condition THEN statement [ELSE statement]`
- `WHILE condition DO statement`
- Nested blocks using `BEGIN ... END`.

### 4. Expressions and Assignments
- Assignment operator: `:=`
- Arithmetic operators: `+`, `-`, `*`, `/`.
- Comparison operators: `==`, `<>`, `<`, `>`, `<=`, `>=`.
- Basic semantic validation: Ensures variables are declared before use and checks for type compatibility (e.g., cannot assign a `FLOAT` value to an `INT` variable).

### 5. Input/Output
- Output functions: `WRITE`, `WRITELN`, `PRINT`.

### 6. Comments
- Single-line comments starting with `//`.

## Execution Flow

1. **User Input**: Source code is entered into the `FrmCompilador` text area.
2. **Lexical Analysis**: `AnalizadorLexico` scans the text, converting it into a list of `Token` objects based on the `MatrizTransicion`.
3. **Syntactic Analysis**: `AnalizadorSintactico` processes the tokens to ensure they follow the language grammar.
4. **Semantic Validation**: During parsing, the application checks if variables are declared and types are consistent.
5. **Results Display**: Any lexical errors, syntax errors, or successfully generated tokens are displayed in the UI.
