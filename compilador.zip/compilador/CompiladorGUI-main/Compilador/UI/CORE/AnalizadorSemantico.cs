using System;
using System.Collections.Generic;
using System.Linq;

namespace Compilador.UI.CORE
{
    public class AnalizadorSemantico
    {
        public List<Simbolo> TablaSimbolos { get; private set; }
        public List<string> Errores { get; private set; }

        public AnalizadorSemantico()
        {
            TablaSimbolos = new List<Simbolo>();
            Errores = new List<string>();
        }

        public void Limpiar()
        {
            TablaSimbolos.Clear();
            Errores.Clear();
        }

        public void RegistrarVariable(string nombre, string tipo, int linea)
        {
            if (TablaSimbolos.Any(s => s.Nombre == nombre))
            {
                Errores.Add($"Error semántico en línea {linea}: La variable '{nombre}' ya ha sido declarada.");
            }
            else
            {
                TablaSimbolos.Add(new Simbolo(nombre, tipo, linea));
            }
        }

        public Simbolo ObtenerSimbolo(string nombre)
        {
            return TablaSimbolos.FirstOrDefault(s => s.Nombre == nombre);
        }

        public bool VerificarDeclaracion(string nombre, int linea)
        {
            var simbolo = ObtenerSimbolo(nombre);
            if (simbolo == null)
            {
                Errores.Add($"Error semántico en línea {linea}: La variable '{nombre}' no ha sido declarada.");
                return false;
            }
            return true;
        }

        public void ValidarAsignacion(string nombreVariable, int tipoValorToken, int linea)
        {
            var simbolo = ObtenerSimbolo(nombreVariable);
            if (simbolo == null) return; // Ya reportado por VerificarDeclaracion

            // TKN_REAL = 202, TKN_ENTERO = 201 (según AnalizadorSintactico)
            if (tipoValorToken == 202 && simbolo.Tipo == "INT")
            {
                Errores.Add($"Error semántico en línea {linea}: No se puede asignar un valor FLOAT a la variable '{nombreVariable}' de tipo INT.");
            }
        }
    }
}
